#include "parser.h"

#define MAXEXP 1000
#define EVAL_ERR -1
#define EVAL_EXIT 1
#define EVAL_SUCCESS 0

/* registers */
float reg_a;
float reg_b;
float reg_c;
float reg_ans;

int eval(Tree *t, float *result);

int main(void) {
	Tree *t;
	float *result = malloc(sizeof(float));
	int retval;
	char buf[MAXEXP];

	printf("\n");
	printf("--------------------------------------------\n");
	printf("Welcome to calc>, where dreams come true.\n");
	printf("Type in your expressions lisp-style.\n");
	printf("Press ctrl-D or type (exit) to quit\n");
	printf("--------------------------------------------\n");
	printf("\n");
	printf("calc> ");

	while (fgets(buf, MAXEXP, stdin)) {
		/* parsing */
		buf[strlen(buf)-1] = '\0';
		if ((t = parse(buf)) == NULL) {
			printf("calc> ");
			continue;
		}
		/* evaluation */
		retval = eval(t, result);
		if (retval == EVAL_ERR) {
			printf("calc> ");
			continue;
		}
		else if (retval == EVAL_EXIT)
			break;
		reg_ans = *result;
		printf("%f\n", reg_ans);
		printf("calc> ");
	}
	free(result);

	return 0;
}

int eval(Tree *t, float *result) {
	List *arglist = List_new();
	Tree *tptr = Tree_first_child(t);
	Node *ptr;
	char *proc;
	float n;

	/* fetch the procedure */
	proc = tptr->datum;

	/* replace arguments in tree with correct values */
	for (tptr = Tree_next_sibling(tptr); tptr != NULL; tptr = Tree_next_sibling(tptr)) {
		/* find real value if needed */
		if (tptr->datum == NULL) {
			if (eval(tptr, result) == EVAL_ERR)
				return EVAL_ERR;
			n = *result;
		}
		else {
			/* fetch register */
			if (!(strcmp(tptr->datum, "a")))
				n = reg_a;
			else if (!(strcmp(tptr->datum, "b")))
				n = reg_b;
			else if (!(strcmp(tptr->datum, "c")))
				n = reg_c;
			else if (!(strcmp(tptr->datum, "ans")))
				n = reg_ans;
			else
				n = atof(tptr->datum);
		}
		/* replace tree string with real value */
		free(tptr->datum);
		tptr->datum = malloc(sizeof(float));
		*((float *)(tptr->datum)) = n;
		/* put it in list */
		List_append(arglist, tptr->datum);
	}

	if (proc == NULL) {
		printf("error: missing procedure\n");
		return EVAL_ERR;
	}
	/* elementary arithmetic */
	else if (!(strcmp(proc, "*"))) {
		if (List_first(arglist) == NULL) {
			printf("error: wrong number of arguments\n");
			return EVAL_ERR;
		}
		*result = *((float *)(List_first(arglist)->data));
		for (ptr = List_first(arglist)->next; ptr != NULL; ptr = ptr->next)
			*result *= *((float *)ptr->data);
	}
	else if (!(strcmp(proc, "+"))) {
		if (List_first(arglist) == NULL) {
			printf("error: wrong number of arguments\n");
			return EVAL_ERR;
		}
		*result = *((float *)(List_first(arglist)->data));
		for (ptr = List_first(arglist)->next; ptr != NULL; ptr = ptr->next)
			*result += *((float *)ptr->data);
	}
	else if (!(strcmp(proc, "-"))) {
		if (List_first(arglist) == NULL) {
			printf("error: wrong number of arguments\n");
			return EVAL_ERR;
		}
		*result = *((float *)(List_first(arglist)->data));
		for (ptr = List_first(arglist)->next; ptr != NULL; ptr = ptr->next)
			*result -= *((float *)ptr->data);
	}
	else if (!(strcmp(proc, "/"))) {
		if (List_first(arglist) == NULL) {
			printf("error: wrong number of arguments\n");
			return EVAL_ERR;
		}
		*result = *((float *)(List_first(arglist)->data));
		for (ptr = List_first(arglist)->next; ptr != NULL; ptr = ptr->next)
			*result /= *((float *)ptr->data);
	}
	/* store register */
	else if (!(strcmp(proc, "a")))
		*result = reg_a = *((float *)(List_first(arglist)->data));
	else if (!(strcmp(proc, "b")))
		*result = reg_b = *((float *)(List_first(arglist)->data));
	else if (!(strcmp(proc, "c")))
		*result = reg_c = *((float *)(List_first(arglist)->data));
	/* quit */
	else if (!(strcmp(proc, "exit")))
		return EVAL_EXIT;
	else {
		printf("error: unsupported procedure \"%s\"\n", proc);
		return EVAL_ERR;
	}

	/* free list */
	List_remove_all(arglist);
	/* free children */
	Tree_remove_children(t);

	return EVAL_SUCCESS;
}
