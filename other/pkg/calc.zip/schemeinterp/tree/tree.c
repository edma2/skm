/* Uses node and list api */

#include "tree.h"

Tree *Tree_new(void *data) {
	Tree *t = malloc(sizeof(Tree));

	if (t == NULL)
		return NULL;
	t->datum = data; 
	t->children = List_new();
	/* no siblings or parents */
	t->parent = NULL;

	return t;
}

/* set the data */
void Tree_set(Tree *t, void *data) {
	if (t == NULL)
		return;
	t->datum = data;
}

/* branch out at parent tree (add child) */
Tree *Tree_add_child(Tree *parent, void *data) {
	Tree *t = Tree_new(data);

	if (t == NULL || parent == NULL)
		return NULL;
	/* connect parent */
	t->parent = parent;
	/* add to list */
	List_append(parent->children, t);

	return t;
}

Tree *Tree_add_sibling(Tree *t, void *data) {
	if (t == NULL || t->parent == NULL)
		return NULL;

	return Tree_add_child(t->parent, data);
}

/* return the parent */
Tree *Tree_parent(Tree *t) {
	if (t == NULL)
		return NULL;
	return t->parent;
}

/* return the first child of parent */
Tree *Tree_first_child(Tree *parent) {
	if (parent == NULL)
		return NULL;
	return List_first(parent->children)->data;
}

/* return the next tree on the same level */
Tree *Tree_next_sibling(Tree *t) {
	Node *ptr;

	if (t == NULL || t->parent == NULL)
		return NULL;
	/* get the pointer to the first node */
	for (ptr = t->parent->children->head; ptr != NULL; ptr = ptr->next) {
		if (ptr->data == t)
			break;
	}
	if (ptr == NULL || ptr->next == NULL)
		return NULL;
	return ptr->next->data;
}

/* print a tree recursively, revealing its heiarchal structure */
void Tree_print(Tree *t, int depth) {
	Node *ptr;
	int d;

	for (d = depth; d > 0; d--)
		printf("- ");
	printf("\\");
	if (t->datum == NULL)
		printf("NULL\n");
	else
		printf("%s\n", (char *)(t->datum));
	for (ptr = t->children->head; ptr != NULL; ptr = ptr->next)
		Tree_print((Tree *)ptr->data, depth + 1);
}

/* delete all of a tree's children */
void Tree_remove_children(Tree *t) {
	List_remove_all(t->children);
}
