/* list.c - a singly linked list implementation
 * badly written by Eugene Ma */

#include "list.h"

/* create an empty list */
List *List_new(void) {
	List *tmp = malloc(sizeof(List));

	/* check if malloc() succeeded */
	if (tmp == NULL)
		return NULL;
	/* empty list */
	tmp->head = NULL;
	tmp->length = 0;

	return tmp;
}

/* add new node to end of list */
void List_append(List *lst, void *data) {
	Node *ptr;

	for (ptr = lst->head; ptr != NULL && ptr->next != NULL; ptr = ptr->next)
		;
	/* new head if empty list */
	if (ptr == NULL)
		lst->head = ptr = Node_create(data);
	else 
		ptr = Node_insert(ptr, data);
	/* check if malloc succeeded */
	if (ptr == NULL)
		return;
	(lst->length)++;
}

/* return the last node's data */
Node *List_last(List *lst) {
	Node *ptr;

	/* check emptiness */
	if (lst == NULL || lst->head == NULL)
		return NULL;
	/* find last node */
	for (ptr = lst->head; ptr->next != NULL; ptr = ptr->next)
		;

	return ptr;
}

Node *List_first(List *lst) {
	if (lst == NULL || lst->head == NULL)
		return NULL;
	return lst->head;
}

/* call func on data of each node in lst */
void List_tranverse(List *lst, void (*func)(void *data)) {
	Node *ptr;

	/* empty list */
	if (lst->head == NULL)
		return;
	for (ptr = lst->head; ptr != NULL; ptr = ptr->next)
		(* func)(ptr->data);
}

/* delete the first node of the list */
void List_remove_first(List *lst) {
	Node *tmp = lst->head;

	if (tmp == NULL)
		return;
	lst->head = tmp->next;
	/* delete data */
	free(tmp->data);
	/* delete node */
	free(tmp);
	(lst->length)--;
}

/* free all nodes and data */
void List_remove_all(List *lst) {
	while (lst->head != NULL)
		List_remove_first(lst);
}

/* debug */
void List_print(List *lst) {
	Node *ptr;
	for (ptr = lst->head; ptr != NULL; ptr = ptr->next)
		printf("%s\n", (char *)(ptr->data));
}
