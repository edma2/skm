/* List data structure : 
 * A singly linked list of nodes
 */
#include "node.h"

/* singly linked lists */
struct List{
	Node *head;						/* first item in list */ 
	int length;						/* length */
};
typedef struct List List;

List *List_new(void); 						/* instantiate empty list (head points to NULL) */
Node *List_last(List *lst); 					/* return the last Node in List */
Node *List_first(List *lst);					/* return the first Node in List */
void List_append(List *lst, void *data);			/* add to end */
void List_remove_first(List *lst); 				/* set head to head->next and delete previous head */
void List_remove_all(List *lst);
void List_print(List *lst); 					/* debug utility */
void List_tranverse(List *lst, void (*func)(void *data)); 	/* call func on data of each node in lst */
