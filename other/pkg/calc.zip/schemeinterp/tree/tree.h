/* Tree data structure : 
 * Each struct Tree represents a node in the heirarchy
 * the children field is a List of nodes, each of which
 * point to a tree.
 * A particular tree's child tree can be accessed by getting
 * its first child and getting next the next child repeatedly.
 */
#include "list.h"

struct Tree {
	void *datum;				/* current datum */
	List *children;				/* list of child trees */
	struct Tree *parent;			/* pointer to parent tree */
};
typedef struct Tree Tree;

Tree *Tree_new(void *data);			/* return an orphaned tree */
Tree *Tree_parent(Tree *t);			/* return parent */
Tree *Tree_first_child(Tree *parent);		/* return first child */
Tree *Tree_next_sibling(Tree *t); 		/* return next sibling */
Tree *Tree_add_child(Tree *parent, void *data); /* add a child to parent */
Tree *Tree_add_sibling(Tree *t, void *data);	/* add sibling */
void Tree_set(Tree *t, void *data); 		/* t->datum = data */
void Tree_print(Tree *t, int depth);    	/* print an informative diagram */
void Tree_remove_children(Tree *t);		/* delete all of a tree's children and datum */
