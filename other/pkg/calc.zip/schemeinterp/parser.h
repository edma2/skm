#include "tree/tree.h"

#define STATE_BEGIN 0
#define STATE_OPEN_PAREN 1
#define STATE_CLOSE_PAREN 2
#define STATE_PROC 3
#define STATE_ARG 4
#define STATE_END 5
#define STATE_ERROR 6

#define MAX_WORD 20
#define TYPE_PROC 0
#define TYPE_ARG 1

Tree *parse(char *exp);
void add_word(Tree *t, void *data, int type);
