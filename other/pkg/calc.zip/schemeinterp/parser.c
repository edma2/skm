#include "parser.h"

static Tree *branch_up(Tree *t);
static Tree *branch_down(Tree *t);

static Tree *branch_up(Tree *t) {
	return Tree_add_child(t, NULL);
}

static Tree *branch_down(Tree *t) {
	if (t->parent == NULL)
		return t;
	return Tree_parent(t);
}

void add_word(Tree *t, void *data, int type) {
	Tree_add_child(t, data);
}

Tree *parse(char *exp) {
	Tree *root = Tree_new(NULL);
	int state = STATE_BEGIN;	
	int layer = 0;
	char *ptr = exp;
	char buf[MAX_WORD];
	int i = 0; 		

	memset(buf, 0, MAX_WORD);
	state = STATE_BEGIN;
	do {
		if (state == STATE_BEGIN) {
			/* go to first open paren */
			if (*ptr == '(') {
				layer++;
				state = STATE_OPEN_PAREN;
			}
		}
		else if (state == STATE_OPEN_PAREN) {
			if (*ptr == ')') {
				state = STATE_ERROR;
				printf("error: premature closing paren\n");
			}
			else if (*ptr == '(') {
				layer++;
				root = branch_up(root);
				state = STATE_OPEN_PAREN;
			}
			else if (*ptr != ' ') {
				buf[i++] = *ptr;
				state = STATE_PROC;
			}
		}
		else if (state == STATE_CLOSE_PAREN) {
			if (layer <= 0) {
				state = STATE_ERROR;
				printf("error: excess close paren\n");
			}
			/* go to next buf */
			else if (*ptr == ')') {
				layer--;
				root = branch_down(root);
				state = STATE_CLOSE_PAREN;
			}
			else if (*ptr == '(') {
				layer++;
				root = branch_up(root);
				state = STATE_OPEN_PAREN;
			}
			else if (*ptr != ' ') {
				buf[i++] = *ptr;
				state = STATE_ARG;
			}
		}
		else if (state == STATE_PROC || STATE_ARG) {
			if (buf[0] != '\0' && (*ptr == ' ' || *ptr == ')')) {
				/* terminate buf */
				buf[i] = '\0';
				if (state == STATE_PROC)
					add_word(root, strdup(buf), TYPE_PROC);
				else
					add_word(root, strdup(buf), TYPE_ARG);
				/* reset buf */
				buf[0] = '\0';
				i = 0;
				/* read next buf or close paren */
				state = STATE_ARG;
			}
			if (*ptr == ')') {
				layer--;
				root = branch_down(root);
				state = STATE_CLOSE_PAREN;
			}
			else if (*ptr == '(') {
				layer++;
				root = branch_up(root);
				state = STATE_OPEN_PAREN;
			}
			else if (*ptr != ' ')
				buf[i++] = *ptr;
		}
		ptr++;
	} while (*ptr != '\0' && state != STATE_ERROR);
	if (state != STATE_ERROR && state == STATE_BEGIN) {
		printf("error: missing expression\n");
		state = STATE_ERROR;
	}
	else if (state != STATE_ERROR && layer > 0) {
		printf("error: excess open paren\n");
		state = STATE_ERROR;
	}

	return (state == STATE_ERROR) ? NULL : root;
}
